from setuptools import setup

setup(
    name = "paquete",
    version = "0.1",
    description = "Paquete de ejemplo",
    author = "Edgar Guamo", 
    author_email = "edgarguamo@gmail.com",
    url = "www.noexite.com",
    scripts = [],
    packages = ["paquete","paquete.adios", "paquete.bienvenido"]
)

 
