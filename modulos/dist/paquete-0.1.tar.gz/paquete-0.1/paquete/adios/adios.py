def adios():
    print("Adios, metodo")

class Adios():
    def __init__(self):
        print("Adios, clase")
