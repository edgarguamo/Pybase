def bienvenido():
    print("Meotodo bienvenido")

class Bienvenido():
    def __init__(self):
        print("Bienvenido clase")
