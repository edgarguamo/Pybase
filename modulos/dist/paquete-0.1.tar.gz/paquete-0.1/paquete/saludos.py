def saludar ():
    print("Holla, te saludo desde el metodo saludar") 

class Saludo ():
    def __init__(self):
        print("Hola, te saludo desde la clase Saludo")

